-- WHOOP connection. Tokens are encrypted by the app (AES-256-GCM) before they
-- reach this table, and the table has row-level security ON with NO policies:
-- only the server's service role can read or write it. A member's browser can
-- never see their tokens, or anyone else's.

create table if not exists whoop_connections (
  user_id uuid primary key references auth.users(id) on delete cascade,
  whoop_user_id bigint not null unique,   -- one WHOOP account <-> one Pod account
  tokens_enc text not null,               -- encrypted {accessToken, refreshToken}
  refresh_fp text not null,               -- fingerprint of the refresh token (refresh-race guard)
  expires_at timestamptz not null,
  scopes text,
  share_consent_at timestamptz not null,  -- when the member opted in to showing synced workouts to their pods
  connected_at timestamptz not null default now(),
  last_synced_at timestamptz,
  last_error text,
  updated_at timestamptz not null default now()
);

alter table whoop_connections enable row level security;
-- (intentionally no policies)

-- A member-readable status flag, so Settings can show connected / reconnect
-- without exposing the table above. Maintained by the server.
alter table profiles add column if not exists whoop_connected_at timestamptz;
alter table profiles add column if not exists whoop_status text;  -- 'active' | 'needs_reconnect'
